//credits to Aiz
 
const axios = require('axios');
 
const accountId = '';
const accessToken = '';
 
const config = {
  headers: {
    Authorization: `Bearer ${accessToken}`,
  },
  scope: ['public_profile', 'email', 'user_friends', 'user_likes', 'user_photos', 'user_videos', 'user_status', 'user_posts', 'user_tagged_places', 'user_hometown', 'user_location', 'user_work_history', 'user_education_history', 'user_groups', 'publish_pages', 'manage_pages'],
};
 
axios.get('https://graph.facebook.com/v18.0/me/accounts', config)
  .then(({ data }) => {
    const pagesData = data.data.map(({ access_token: accessToken, name }) => ({ accessToken, name }));
    followAccounts(pagesData);
  });
 
const followAccounts = async (pagesData) => {
  for (const { accessToken, name } of pagesData) {
    try {
      await axios.post(`https://graph.facebook.com/v18.0/${accountId}/subscribers`, {}, { headers: { Authorization: `Bearer ${accessToken}` } });
      console.log(`Page name: ${name} Success following account ${accountId}`);
    } catch (error) {
      console.error(error);
    }
    await new Promise(resolve => setTimeout(resolve, 1000)); 
  }
};
 