const axios = require("axios");

module.exports.config = {
  name: "gscholar",
  version: "1.0.0",
  hasPermission: 0,
  usePrefix: false,
  credits: "Anjelo Cayao Arabis",
  description: "Search for articles on Google Scholar.",
  commandCategory: "educ",
  usages: "Usage: .gscholar [query]",
  cooldowns: 3,
};

module.exports.run = async function ({ api, event, args }) {
  const query = args.join(" ");

  if (!query) {
    return api.sendMessage("Please provide a query to search on Google Scholar.", event.threadID);
  }

  api.sendMessage("🔍 Processing your request...", event.threadID);

  try {
    const response = await axios.get(`https://yukihiraaofficial.yukihirasomaa.repl.co/gscholar?query=${encodeURIComponent(query)}`);

    if (response.data.error) {
      return api.sendMessage(response.data.error, event.threadID);
    }

    const result = response.data.result;
    api.sendMessage(result, event.threadID);
  } catch (error) {
    console.error(error);
    api.sendMessage("An error occurred while processing the request.", event.threadID);
  }
};