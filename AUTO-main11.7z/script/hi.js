module.exports.config = {
    name: "responses",
    version: "1.0.0",
    hasPermssion: 0,
    credits: "",//lagyan nyo nalang :>
    description: "-",
    usePrefix: false,
    commandCategory: "system",
    usages: "[text]",
    cooldowns: 5
}

module.exports.handleEvent = async ({
    event,
    api,
    Users
}) => {

    const axios = require("axios");
    let moment = require("moment-timezone");
	
    //font
    function font(letters) {
        const change = {
            a: "𝖺",
            b: "𝖻",
            c: "𝖼",
            d: "𝖽",
            e: "𝖾",
            f: "𝖿",
            g: "𝗀",
            h: "𝗁",
            i: "𝗂",
            j: "𝗃",
            k: "𝗄",
            l: "𝗅",
            m: "𝗆",
            n: "𝗇",
            o: "𝗈",
            p: "𝗉",
            q: "𝗊",
            r: "𝗋",
            s: "𝗌",
            t: "𝗍",
            u: "𝗎",
            v: "𝗏",
            w: "𝗐",
            x: "𝗑",
            y: "𝗒",
            z: "𝗓",
            A: "𝖠",
            B: "𝖡",
            C: "𝖢",
            D: "𝖣",
            E: "𝖤",
            F: "𝖥",
            G: "𝖦",
            H: "𝖧",
            I: "𝖨",
            J: "𝖩",
            K: "𝖪",
            L: "𝖫",
            M: "𝖬",
            N: "𝖭",
            O: "𝖮",
            P: "𝖯",
            Q: "𝖰",
            R: "𝖱",
            S: "𝖲",
            T: "𝖳",
            U: "𝖴",
            V: "𝖵",
            W: "𝖶",
            X: "𝖷",
            Y: "𝖸",
            Z: "𝖹"
        };
        let formattedFont = "";
        for (let i = 0; i < letters.length; i++) {
            const char = letters[i];
            formattedFont += change[char] || char;
        }
        return formattedFont;
    }
    //font2
    function fontTwo(letters) {
        const change = {
            a: "𝖺",
            b: "𝖻",
            c: "𝖼",
            d: "𝖽",
            e: "𝖾",
            f: "𝖿",
            g: "𝗀",
            h: "𝗁",
            i: "𝗂",
            j: "𝗃",
            k: "𝗄",
            l: "𝗅",
            m: "𝗆",
            n: "𝗇",
            o: "𝗈",
            p: "𝗉",
            q: "𝗊",
            r: "𝗋",
            s: "𝗌",
            t: "𝗍",
            u: "𝗎",
            v: "𝗏",
            w: "𝗐",
            x: "𝗑",
            y: "𝗒",
            z: "𝗓",
            A: "𝖺",
            B: "𝖻",
            C: "𝖼",
            D: "𝖽",
            E: "𝖾",
            F: "𝖿",
            G: "𝗀",
            H: "𝗁",
            I: "𝗂",
            J: "𝗃",
            K: "𝗄",
            L: "𝗅",
            M: "𝗆",
            N: "𝗇",
            O: "𝗈",
            P: "𝗉",
            Q: "𝗊",
            R: "𝗋",
            S: "𝗌",
            T: "𝗍",
            U: "𝗎",
            V: "𝗏",
            W: "𝗐",
            X: "𝗑",
            Y: "𝗒",
            Z: "𝗓",
        };
        let formattedFont = "";
        for (let i = 0; i < letters.length; i++) {
            const char = letters[i];
            formattedFont += change[char] || char;
        }
        return formattedFont;
    }

    //chat	(dagdagan nyo nalang)
    let chat = ["hi", "hii", "hiii", "hiiii", "hello", "helo", "helow", "hellow", "helow", "helloo", "helloo", "elo", "elow", "eloo", "elooo", "low", "loe", "morning", "good morning ", "goodmorning", "aftie", "aftiee", "aftieee", "afternoon", "good afternoon", "eve", "good evening ", "ohayo", "konichiwa", "konbanwa", "hello senyo", "hi senyo", "ey", "yo", "hi rem", "hi sa inyo", "hello sa inyo", "@everyone", ".", "👋", "sup", "zup"];
  
    if (chat.includes(event.body.toLowerCase())) 
		{
		    //api 
    const truthqn = await axios.get(`https://sensui-useless-apis.codersensui.repl.co/api/fun/truth`);
    const dareqn = await axios.get(`https://sensui-useless-apis.codersensui.repl.co/api/fun/dare`);
    const factqn = await axios.get(`https://sensui-useless-apis.codersensui.repl.co/api/fun/facts`);
    const wyrqn = await axios.get(`https://sensui-useless-apis.codersensui.repl.co/api/fun/wouldyourather`);

    //data
    const dare = dareqn.data.question;
    const truth = truthqn.data.question;
    const fact = factqn.data.fact;
    const wyr = wyrqn.data.question;	
    //credits kay jean sa lahat ng api//
          
        //dagdagan nyo nalang to\\
        let responses = [ `bored? i dare you to ${dare}`, `bored? answer this truth question:\n\n${truth}`, `want to know some fact?\n\ndid you know that ${fact}`, `${wyr}`, "bat ka nya iniwan?", "san ka ba nagkulang?", "eat na ikaw?", "kumain kana?", "kumain kana? kasi kung dipa, lakompake", "how's your day?", "musta araw mo?", "alam mo, kung ako yun, di kita gaganunin", "kung may problema ka man sa buhay, problema mo na yun", "kun may problema ka, don't ever think of giving up"];

        let respond = responses[Math.floor(Math.random() * responses.length)];

        //time
        let hours = moment.tz('Asia/Manila').format('HHmm');
        let session = (
            hours > 0001 && hours <= 0400 ? "Bright morning" :
            hours > 0401 && hours <= 0700 ? "Good morning" :
            hours > 0701 && hours <= 1000 ? "Ohayo gozaimasu" :
            hours > 1001 && hours <= 1100 ? "Ohayo" :
            hours > 1100 && hours <= 1200 ? "Good noon" :
            hours > 1201 && hours <= 1800 ? "Good afternoon" :
            hours > 1801 && hours <= 2100 ? "Good evening" :
            hours > 2101 && hours <= 2350 ? "Konbanwa" :
            hours > 2359 && hours <= 2400 ? "Nightyy" :
            "hello");
        //user
        let {
            threadID,
            messageID,
            senderID
        } = event;
        const getUserInfo = async (api, userID) => {
            try {
                const userInfo = await api.getUserInfo(userID);
                return userInfo[userID].firstName;
            } catch (error) {
                console.error(`Error fetching user info: ${error}`);
                return "";
            }
        };
        const userInfo = await getUserInfo(api, senderID);

        api.sendMessage(
            {
                body: font(`${session} ${userInfo}, `) + fontTwo(`${respond}`),
                mentions: [
                    {
                        tag: userInfo,
                        id: senderID,
                    },
                ],
            },
            threadID,
            messageID
        );
    }
	} 